TYPE_CHOICES = [
    ('bug', 'Bug'),
    ('suggestion', 'Suggestion'),
    ('needs', 'Needs')
]